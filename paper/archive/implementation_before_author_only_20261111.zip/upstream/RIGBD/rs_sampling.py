"""提取作者RS采样函数，仅移除未使用的self形参。"""
import torch
from torch.distributions.bernoulli import Bernoulli

def sample_noise_all( prob_drop, edge_index, edge_weight,device):
        prob_retain = 1 - prob_drop
        noisy_edge_index = edge_index.clone().detach()
        if(edge_weight == None):
            noisy_edge_weight = torch.ones([noisy_edge_index.shape[1],]).to(device)
        else:
            noisy_edge_weight = edge_weight.clone().detach()
        # # rand_noise_data = copy.deepcopy(data)
        # rand_noise_data.edge_weight = torch.ones([rand_noise_data.edge_index.shape[1],]).to(device)
        m = Bernoulli(torch.tensor([prob_retain]).to(device))
        mask = m.sample(noisy_edge_weight.shape).squeeze(-1).int()
        rand_inputs = torch.randint_like(noisy_edge_weight, low=0, high=2).squeeze().int().to(device)
        # print(rand_noise_data.edge_weight.shape,mask.shape)
        noisy_edge_weight = noisy_edge_weight * mask #+ rand_inputs * (1-mask)

        if(noisy_edge_weight!=None):
            noisy_edge_index = noisy_edge_index[:,noisy_edge_weight.nonzero().flatten().long()]
            noisy_edge_weight = torch.ones([noisy_edge_index.shape[1],]).to(device)
        return noisy_edge_index, noisy_edge_weight
