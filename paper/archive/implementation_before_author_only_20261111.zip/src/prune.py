"""Prune：调用作者余弦相似度筛边，在训练和每张评估图上分别处理。"""
from copy import copy
from types import SimpleNamespace
from upstream.RIGBD.prune import prune_unrelated_edge
from .models import make_model, describe
from .training import fit_classifier
from .common import start_clock, elapsed


def filter_graph(x, edges, weights, threshold):
    settings = SimpleNamespace(prune_thr=threshold)
    return prune_unrelated_edge(settings, edges, weights, x, x.device, large_graph=edges.size(1) > 20000)


def train(data, args, device):
    begin = start_clock(device)
    working = copy(data)
    working["edges"], working["weights"] = filter_graph(data["x"], data["edges"], data["weights"], args.prune_threshold)
    processing = elapsed(begin, device)
    model = make_model(data, args, device, "rigbd")
    begin = start_clock(device)
    history = fit_classifier(model, working, args.epochs, args.lr, args.weight_decay, "Prune分类训练")
    return model, {"family": "rigbd", "final_model": describe(model), "threshold": args.prune_threshold,
                   "training_edges_before": data["edges"].size(1), "training_edges_after": working["edges"].size(1),
                   "source": "upstream/RIGBD/help_funcs.py::prune_unrelated_edge",
                   "checkpoint_rule": "best_validation", "history": history,
                   "phases": {"graph_processing": processing, "training": elapsed(begin, device)}}
