"""RIGBD评分与恢复；三个骨架均使用对应作者模型。"""
import math
import torch
import torch.nn.functional as F
from tqdm.auto import tqdm
from .common import setup, start_clock, elapsed
from .models import make_model, describe
from .training import fit_classifier
from upstream.RIGBD.sampling import sample_noise_all


@torch.no_grad()
def score_nodes(model, data, repeats, drop_ratio=0.5, sampling="incoming"):
    if repeats < 1 or not 0 <= drop_ratio < 1:
        raise ValueError("RIGBD重复次数须为正，丢边率须在[0,1)内。")
    model.eval()
    reference = F.log_softmax(model(data["x"], data["edges"], data["weights"]), dim=-1)
    probabilities = reference.exp()
    scores = torch.zeros(data["x"].size(0), device=data["x"].device)
    for _ in tqdm(range(repeats), desc="RIGBD随机丢边评分", unit="次", leave=False):
        # 0.5时直接使用作者逐字采样函数；其他显式概率使用同一规则。
        if sampling == "paired":
            edges, weights = sample_paired(data, drop_ratio)
        elif sampling == "incoming":
            edges, weights = sample_at_ratio(data, drop_ratio, restore_axis=1)
        elif sampling == "author" and drop_ratio == 0.5:
            edges, weights = sample_noise_all(data["edges"], data["weights"], data["x"].device)
        elif sampling == "author":
            edges, weights = sample_at_ratio(data, drop_ratio, restore_axis=0)
        else:
            raise ValueError("未知RIGBD丢边协议。")
        changed = F.log_softmax(model(data["x"], edges, weights), dim=-1)
        scores += (probabilities * (reference - changed)).sum(dim=-1)
    return scores / repeats


def sample_at_ratio(data, drop_ratio, restore_axis=0):
    from torch.distributions import Bernoulli
    edges, weights = data["edges"], data["weights"]
    keep = Bernoulli(1 - drop_ratio).sample(weights.size()).bool()
    sampled = edges[:, keep]
    sampled_weights = weights[keep]
    degree = torch.zeros(data["x"].size(0), device=edges.device)
    degree.index_add_(0, sampled[restore_axis], torch.ones(sampled.size(1), device=edges.device))
    restore = degree[edges[restore_axis]] == 0
    return torch.cat([sampled, edges[:, restore]], dim=1), torch.cat([sampled_weights, weights.new_ones(int(restore.sum()))])


def sample_paired(data, drop_ratio):
    # 无向配对作为独立变体，丢弃和孤立恢复都以整条无向连接为单位。
    edges, weights = data["edges"], data["weights"]
    count = data["x"].size(0)
    lower = torch.minimum(edges[0], edges[1])
    upper = torch.maximum(edges[0], edges[1])
    keys, inverse = torch.unique(lower * count + upper, return_inverse=True)
    choices = torch.rand(keys.numel(), device=edges.device) >= drop_ratio
    keep = choices[inverse]
    degree = torch.bincount(edges[1, keep], minlength=count)
    restore = (degree[edges[0]] == 0) | (degree[edges[1]] == 0)
    choices[inverse[restore]] = True
    keep = choices[inverse]
    return edges[:, keep], weights[keep]


def probe_checkpoint(args):
    rule = getattr(args, "rigbd_probe_checkpoint", "author")
    if rule == "author":
        rule = "last" if args.model == "GCN" else "best_validation"
    return rule


def select_nodes(scores, data):
    # 按论文的自动阈值规则推断目标类，不读取生成目标或真实附着名单。
    order = data["train"][torch.argsort(scores[data["train"]], descending=True)]
    target = int(data["labels"][order[0]])
    labels = data["labels"][order]
    stop = None
    for index in range(order.numel() - 1):
        if int(labels[index]) != target and int(labels[index + 1]) != target:
            stop = index
            break
    selected = order
    if stop is not None:
        selected = order[scores[order] > scores[order[stop]]]
    return selected, target


def recover(model, data, selected, target, args):
    # 用节点值做差集，修正作者Tensor集合不能可靠做差的问题。
    normal = data["train"][~torch.isin(data["train"], selected)]
    if normal.numel() == 0:
        raise RuntimeError("RIGBD没有保留普通训练节点，请检查评分与数据。")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    history = []
    for epoch in tqdm(range(args.epochs), desc="RIGBD最终恢复训练", unit="轮", leave=False):
        model.train()
        optimizer.zero_grad()
        output = model(data["x"], data["edges"], data["weights"])
        if args.rigbd_loss == "source":
            normal_loss = F.cross_entropy(output[normal], data["labels"][normal])
            probabilities = F.softmax(output[selected], dim=-1)
            penalty = probabilities.gather(1, data["labels"][selected, None]).mean()
            loss = normal_loss + penalty
        else:
            normal_loss = F.cross_entropy(output[normal], data["labels"][normal], reduction="sum")
            log_target = F.log_softmax(output[selected], dim=-1)[:, target]
            log_target = log_target.clamp_min(math.log(1e-8))
            loss = (normal_loss + log_target.sum()) / data["train"].numel()
        if not torch.isfinite(loss):
            raise RuntimeError("RIGBD恢复训练出现非有限损失。")
        loss.backward()
        optimizer.step()
        item = {"epoch": epoch + 1, "loss": loss.item()}
        if epoch == 0 or epoch + 1 == args.epochs or (epoch + 1) % 50 == 0:
            item["normal_group_loss"] = normal_loss.item()
            item["selected_group_term"] = penalty.item() if args.rigbd_loss == "source" else log_target.sum().item()
        history.append(item)
    model.eval()
    return history


def train(data, args, device):
    begin = start_clock(device)
    probe = make_model(data, args, device, "rigbd", scoring=True)
    probe_description = describe(probe)
    fit_classifier(probe, data, args.rigbd_probe_epochs, args.lr, args.weight_decay,
                   "RIGBD评分模型（" + args.model + "）", checkpoint_rule=probe_checkpoint(args))
    probe_description["training_selection"] = probe.training_selection
    prepare_seconds = elapsed(begin, device)
    begin = start_clock(device)
    scores = score_nodes(probe, data, args.rigbd_repeats, getattr(args, "rigbd_drop_ratio", 0.5),
                         getattr(args, "rigbd_sampling", "incoming"))
    selected, target = select_nodes(scores, data)
    score_seconds = elapsed(begin, device)
    del probe
    setup(args.seed, str(device))
    model = make_model(data, args, device, "rigbd")
    begin = start_clock(device)
    if selected.numel() == 0:
        history = fit_classifier(model, data, args.epochs, args.lr, args.weight_decay, "RIGBD空候选普通训练")
    else:
        history = recover(model, data, selected, target, args)
    details = {"family": "rigbd", "scoring_model": probe_description, "final_model": describe(model),
               "selected_nodes": selected.cpu().tolist(), "inferred_target": target,
               "loss": args.rigbd_loss, "checkpoint_rule": "last" if selected.numel() else "best_validation",
               "probe_checkpoint": probe_checkpoint(args), "drop_ratio": getattr(args, "rigbd_drop_ratio", 0.5),
               "sampling": getattr(args, "rigbd_sampling", "incoming"),
               "selection_protocol": "论文自动目标与严格阈值；不读取真实目标、真实数量或真实名单",
               "initialization_protocol": "各阶段独立重置种子，构造器初始化；与作者连续随机流分开记录",
               "phases": {"preparation": prepare_seconds, "score_and_selection": score_seconds,
                          "final_training": elapsed(begin, device)}, "history": history}
    return model, details
