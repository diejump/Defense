"""Cora固定准备模型：伪标签接口与作者全原节点标签接口分开诊断。"""
import argparse
import hashlib
import json
import random
from copy import deepcopy
from pathlib import Path
import numpy as np
import torch
from src.config import parser
from src.common import setup, load_training, save_json
from src.models import make_model
from src.training import fit_classifier
from src.evaluation import evaluate
from upstream.DShield.NodeClassificationTasks.defense.dshield import dshield


def main():
    p = argparse.ArgumentParser(description="仅Cora的DShield标签接口控制实验")
    p.add_argument("--bundle", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    options = p.parse_args()
    info = json.loads((options.bundle / "metadata.json").read_text(encoding="utf-8"))
    if info["settings"]["dataset"] != "Cora":
        raise ValueError("只允许Cora数据集。")
    options.output.mkdir(parents=True, exist_ok=False)
    args = parser("DShield标签控制").parse_args([])
    args.dataset, args.attack, args.model = "Cora", info["settings"]["attack"], "GraphSAGE"
    device = setup(args.seed, args.device)
    data = load_training(options.bundle, device)
    truth = torch.load(options.bundle / "evaluation.pt", map_location=device)
    probe = make_model(data, args, device, "dshield")
    fit_classifier(probe, data, args.epochs, args.lr, args.weight_decay, "固定DShield准备模型")
    with torch.no_grad():
        pseudo = probe(data["x"], data["edges"], data["weights"])[:data["labels"].numel()].argmax(-1)
    known = data["labels"] >= 0
    pseudo[known] = data["labels"][known]
    full = truth["truth"].clone()
    full[known] = data["labels"][known]
    state_hash = hashlib.sha256()
    for value in probe.state_dict().values():
        state_hash.update(value.detach().cpu().numpy().tobytes())
    cpu_rng, numpy_rng, python_rng = torch.get_rng_state(), np.random.get_state(), random.getstate()
    cuda_rng = torch.cuda.get_rng_state(device)
    rows = []
    for mode, labels in [("pseudo_labels", pseudo), ("full_original_labels_reference", full)]:
        torch.set_rng_state(cpu_rng)
        torch.cuda.set_rng_state(cuda_rng, device)
        np.random.set_state(numpy_rng)
        random.setstate(python_rng)
        row = {"mode": mode, "uses_evaluator_truth": mode != "pseudo_labels",
               "prepared_model_sha256": state_hash.hexdigest(), "status": "running"}
        try:
            model, selected = dshield(deepcopy(probe), data["x"], data["edges"], data["weights"], labels.clone(),
                data["train"], torch.empty(0, dtype=torch.long, device=device), data["val"], args.hidden,
                lr=args.lr, weight_decay=args.weight_decay, kappa1=args.kappa1, kappa2=args.kappa2,
                kappa3=args.kappa3, thresh=args.dshield_threshold, edge_drop_ratio=args.dshield_edge_drop,
                feature_drop_ratio=args.dshield_feature_drop, tau=args.dshield_temperature,
                pretrain_epochs=args.dshield_pretrain, classify_epochs=args.epochs,
                finetune_epochs=args.dshield_finetune, device=device, balance_factor=args.dshield_balance,
                classify_rounds=1, dataset="Cora", arch="GraphSage", attack_name=args.attack, rtn_node_idx=True)
            details = {"selected_nodes": selected.cpu().tolist()}
            metrics = evaluate(model, data, options.bundle, "dshield", details, device, args)
            row.update(status="complete", metrics=metrics,
                       internal_phases=model.dshield_phase_seconds, recovery=model.dshield_recovery_info)
        except Exception as error:
            row.update(status="failed", error=type(error).__name__ + ": " + str(error))
        rows.append(row)
        save_json(options.output / "results.json", {"dataset": "Cora", "model": "GraphSAGE",
            "bundle_id": info["bundle_id"], "cases": rows,
            "interpretation": "同一准备权重与起始随机状态；全标签案例含测试标签，只作接口诊断，不进入正式比较。"})
        print(mode, row["status"], row.get("metrics", {}).get("ASR"), flush=True)
    save_json(options.output / "completion.json", {"status": "complete", "cases": len(rows)})


if __name__ == "__main__":
    main()
