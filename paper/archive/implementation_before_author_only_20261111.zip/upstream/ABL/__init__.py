"""ABL作者原始实现资料；GNN适配见src/abl.py。"""
