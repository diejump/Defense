"""结构RS适配：随机丢边训练，独立多次预测后多数投票。"""
from copy import deepcopy
import torch
import torch.nn.functional as F
from tqdm.auto import tqdm
from upstream.RIGBD.rs_sampling import sample_noise_all
from .models import make_model, describe


def train(data, args, device):
    if not 0 < args.rs_drop_ratio < 1 or args.rs_samples < 1:
        raise ValueError("RS丢边率须在(0,1)内，投票次数须为正数。")
    model = make_model(data, args, device, "rigbd")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    best_accuracy = -1.0
    best_state = deepcopy(model.state_dict())
    history = []
    for epoch in tqdm(range(args.epochs), desc="结构RS随机丢边训练", unit="轮", leave=False):
        model.train()
        optimizer.zero_grad()
        edges, weights = sample_noise_all(args.rs_drop_ratio, data["edges"], data["weights"], device)
        output = model(data["x"], edges, weights)
        loss = F.cross_entropy(output[data["train"]], data["labels"][data["train"]])
        if not torch.isfinite(loss):
            raise RuntimeError("RS出现非有限训练损失。")
        loss.backward()
        optimizer.step()
        model.eval()
        with torch.no_grad():
            edges, weights = sample_noise_all(args.rs_drop_ratio, data["edges"], data["weights"], device)
            output = model(data["x"], edges, weights)
            accuracy = output[data["val"]].argmax(-1).eq(data["labels"][data["val"]]).float().mean().item()
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_state = deepcopy(model.state_dict())
        history.append({"epoch": epoch + 1, "loss": loss.item(), "val_accuracy": accuracy})
    model.load_state_dict(best_state)
    model.eval()
    return model, {"family": "rigbd", "final_model": describe(model), "history": history,
                   "protocol": "RIGBD论文结构丢边RS适配；不等同于DShield节点采样RS",
                   "source": "upstream/RIGBD/models/random_smooth.py，训练与采样；论文多次预测聚合",
                   "drop_ratio": args.rs_drop_ratio, "prediction_samples": args.rs_samples,
                   "aggregation": "多数投票，平票取类别编号最小者", "checkpoint_rule": "best_validation"}


@torch.no_grad()
def smooth_predict(model, graph, drop_ratio, samples, seed):
    x, edges, weights = graph
    if samples < 1:
        raise ValueError("RS投票次数必须为正数。")
    devices = [x.device.index] if x.device.type == "cuda" else []
    # 保存并恢复随机状态；每张图的固定采样种子使权重重载可复核。
    with torch.random.fork_rng(devices=devices):
        torch.manual_seed(seed)
        votes = None
        for _ in tqdm(range(samples), desc="结构RS独立丢边投票", unit="次", leave=False):
            sampled_edges, sampled_weights = sample_noise_all(drop_ratio, edges, weights, x.device)
            output = model(x, sampled_edges, sampled_weights)
            if not torch.isfinite(output).all():
                raise RuntimeError("RS预测出现非有限分数。")
            if votes is None:
                votes = torch.zeros_like(output)
            predictions = output.argmax(-1, keepdim=True)
            votes.scatter_add_(1, predictions, torch.ones_like(predictions, dtype=output.dtype))
    return votes / samples
