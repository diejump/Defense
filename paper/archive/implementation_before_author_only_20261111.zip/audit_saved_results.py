"""只读取服务器已有结果，导出实际参数、候选命中与分项耗时。"""
import argparse
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description="只读核查已保存结果，不重新训练")
    p.add_argument("--root", type=Path, required=True, help="含runs目录的实验输出根目录")
    p.add_argument("--output", type=Path, default=Path("paper/saved_results_audit.json"), help="核查输出")
    p.add_argument("--dataset", default=None, help="可选的数据集筛选")
    args = p.parse_args()
    rows = []
    for path in sorted((args.root / "runs").rglob("result.json")):
        record = json.loads(path.read_text(encoding="utf-8"))
        if args.dataset is not None and record["dataset"] != args.dataset:
            continue
        settings = record.get("arguments", {})
        details = record.get("details", {})
        metrics = record.get("metrics", {})
        metadata = {}
        if record.get("bundle"):
            metadata_path = Path(record["bundle"]) / "metadata.json"
            if metadata_path.is_file():
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        rows.append({"result": str(path), "status": record["status"], "dataset": record["dataset"],
            "attack": record["attack"], "model": record["model"], "method": record["method"],
            "seed": record["seed"], "hidden": settings.get("hidden"), "epochs": settings.get("epochs"),
            "rigbd_loss": details.get("loss") if record["method"] == "rigbd" else None,
            "probe_checkpoint": details.get("probe_checkpoint", "旧记录未显式保存"),
            "sampling": details.get("sampling", "旧记录未显式保存"),
            "inferred_target": details.get("inferred_target"),
            "actual_attack_target": metadata.get("settings", {}).get("target"),
            "inferred_target_matches": metrics.get("inferred_target_matches"),
            "selected_nodes": details.get("selected_nodes"),
            "early_selection_epoch": details.get("selected_early_epoch"),
            "early_parameters": details.get("early_parameters"),
            "candidate_TP": metrics.get("selection_TP"), "candidate_FP": metrics.get("selection_FP"),
            "candidate_recall": metrics.get("selection_recall"),
            "CA": metrics.get("CA"), "ASR": metrics.get("ASR"),
            "model_build_seconds": metrics.get("model_build_seconds"),
            "phase_seconds": details.get("phases"), "internal_phases": details.get("internal_phases"),
            "recovery_checkpoint": details.get("recovery_checkpoint"),
            "bundle": record.get("bundle"), "bundle_id": record.get("bundle_id"),
            "bundle_counts": record.get("bundle_counts", metadata.get("counts")),
            "generator_parameters": record.get("generator_parameters", metadata.get("actual_generator_parameters")),
            "environment": record.get("environment"),
            "code_sha256": record.get("code_sha256"), "error": record.get("error")})
    if not rows:
        raise ValueError("没有找到匹配的result.json，请指定实际实验根目录。")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"training_executed": False, "records": rows},
                           ensure_ascii=False, indent=2), encoding="utf-8")
    print("只读核查完成，记录数：" + str(len(rows)) + "；输出：" + str(args.output))


if __name__ == "__main__":
    main()
