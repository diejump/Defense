"""仅在Cora固定样本上区分RIGBD评分、选择和恢复的影响。"""
import argparse
import hashlib
import json
from copy import copy
from pathlib import Path
import torch
from tqdm.auto import tqdm
from src.config import parser, ROOT
from src.common import setup, load_training, save_json, cpu_state, start_clock, elapsed
from src.models import make_model, describe
from src.training import fit_classifier
from src.rigbd import score_nodes, select_nodes, recover
from src.evaluation import evaluate


def state_digest(model):
    digest = hashlib.sha256()
    for name, value in model.state_dict().items():
        digest.update(name.encode())
        digest.update(value.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def selection_details(selected, attached):
    found = set(selected.cpu().tolist())
    truth = set(attached.cpu().tolist())
    return {"selected": len(found), "TP": len(found & truth), "FP": len(found - truth),
            "recall": len(found & truth) / len(truth),
            "precision": len(found & truth) / len(found) if found else None}


def select_known_target(scores, data, target):
    # 本函数只在明确标注的真值辅助诊断中调用。
    order = data["train"][scores[data["train"]].argsort(descending=True)]
    labels = data["labels"][order]
    for index in range(len(order) - 1):
        if int(labels[index]) != target and int(labels[index + 1]) != target:
            return order[scores[order] > scores[order[index]]]
    return order


def main():
    p = argparse.ArgumentParser(description="Cora固定样本的RIGBD流程控制实验")
    p.add_argument("--bundle", type=Path, required=True, help="已有Cora样本")
    p.add_argument("--output", type=Path, required=True, help="新的诊断目录")
    p.add_argument("--models", nargs="+", default=["GCN", "GAT", "GraphSAGE"], help="骨架")
    p.add_argument("--device", default="cuda:0", help="设备")
    p.add_argument("--seed", type=int, default=10, help="阶段初始化种子")
    p.add_argument("--hidden", type=int, default=64, help="与待核查运行一致的隐藏宽度")
    p.add_argument("--epochs", type=int, default=400, help="恢复轮数")
    p.add_argument("--probe-epochs", type=int, default=1000, help="评分训练轮数")
    p.add_argument("--repeats", type=int, default=20, help="同一组丢边图数量")
    options = p.parse_args()
    info = json.loads((options.bundle / "metadata.json").read_text(encoding="utf-8"))
    if info["settings"]["dataset"] != "Cora":
        raise ValueError("本轮诊断只允许Cora数据集。")
    options.output.mkdir(parents=True, exist_ok=False)
    args = parser("Cora诊断参数").parse_args([])
    args.dataset, args.attack = "Cora", info["settings"]["attack"]
    args.device, args.seed = options.device, options.seed
    args.hidden, args.epochs = options.hidden, options.epochs
    args.rigbd_probe_epochs, args.rigbd_repeats = options.probe_epochs, options.repeats
    args.rigbd_sampling = "author"
    device = setup(args.seed, args.device)
    data = load_training(options.bundle, device)
    # 真实位置只用于评分核对及单列的真值辅助实验，不传入正式train()。
    truth = torch.load(options.bundle / "evaluation.pt", map_location=device)
    attached, actual_target = truth["attached"], int(truth["target"])
    rows = []
    for backbone in tqdm(options.models, desc="Cora骨架控制实验", unit="种"):
        args.model = backbone
        setup(args.seed, args.device)
        probe = make_model(data, args, device, "rigbd", scoring=True)
        snapshots = {}
        begin = start_clock(device)
        fit_classifier(probe, data, args.rigbd_probe_epochs, args.lr, args.weight_decay,
                       "保存同一训练轨迹的最佳与末轮", snapshots=snapshots)
        train_seconds = elapsed(begin, device)
        cpu_rng = torch.get_rng_state()
        cuda_rng = torch.cuda.get_rng_state(device) if device.type == "cuda" else None
        scores_by_rule = {}
        selections = {}
        for rule in ["best_validation", "last"]:
            probe.load_state_dict(snapshots[rule])
            torch.set_rng_state(cpu_rng)
            if cuda_rng is not None:
                torch.cuda.set_rng_state(cuda_rng, device)
            scores = score_nodes(probe, data, args.rigbd_repeats, sampling="author")
            selected, inferred = select_nodes(scores, data)
            scores_by_rule[rule] = scores
            selections[rule] = (selected, inferred)
        torch.save(snapshots, options.output / (backbone + "_probe_states.pt"))
        automatic, inferred = selections["last"]
        known_target = select_known_target(scores_by_rule["last"], data, actual_target)
        order = data["train"][scores_by_rule["last"][data["train"]].argsort(descending=True)]
        cases = [("best_auto_source", selections["best_validation"][0], selections["best_validation"][1], "source", False),
                 ("last_auto_source", automatic, inferred, "source", False),
                 ("last_auto_paper", automatic, inferred, "paper", False),
                 ("last_known_target_source", known_target, actual_target, "source", True),
                 ("last_true_count_source", order[:attached.numel()], actual_target, "source", True),
                 ("true_ids_source", attached, actual_target, "source", True),
                 ("true_ids_paper", attached, actual_target, "paper", True)]
        del probe
        for name, selected, target, objective, uses_truth in tqdm(cases, desc=backbone + "恢复条件", unit="组", leave=False):
            current = copy(args)
            current.rigbd_loss = objective
            setup(args.seed, args.device)
            model = make_model(data, current, device, "rigbd")
            initial_hash = state_digest(model)
            row = {"model": backbone, "case": name, "uses_evaluator_truth": uses_truth,
                   "inferred_target": target, "target_matches": target == actual_target,
                   "candidate_metrics": selection_details(selected, attached),
                   "initial_parameter_sha256": initial_hash, "objective": objective,
                   "probe_training_seconds": train_seconds, "status": "running"}
            try:
                if selected.numel():
                    history = recover(model, data, selected, target, current)
                else:
                    history = fit_classifier(model, data, current.epochs, current.lr, current.weight_decay, "空候选普通训练")
                metrics = evaluate(model, data, options.bundle, "rigbd", {}, device)
                row.update(status="complete", metrics=metrics, history=history)
                torch.save(cpu_state(model), options.output / (backbone + "_" + name + ".pt"))
            except Exception as error:
                row.update(status="failed", error=type(error).__name__ + ": " + str(error))
            rows.append(row)
            save_json(options.output / "results.json", {"dataset": "Cora", "bundle_id": info["bundle_id"],
                      "arguments": vars(args), "cases": rows,
                      "interpretation": "同一轨迹、相同丢边随机状态；真值辅助案例单列，不进入正式对照表。"})
            print(backbone, name, row["status"], row.get("metrics", {}).get("ASR"), row["candidate_metrics"], flush=True)
            del model
    save_json(options.output / "completion.json", {"status": "complete", "cases": len(rows)})


if __name__ == "__main__":
    main()
