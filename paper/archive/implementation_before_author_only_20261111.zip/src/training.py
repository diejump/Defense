"""普通分类训练：每轮训练一次，再用验证集选择模型。"""
from copy import deepcopy
import torch
import torch.nn.functional as F
from tqdm.auto import tqdm


def fit_classifier(model, data, epochs, lr, weight_decay, title,
                   checkpoint_rule="best_validation", snapshots=None):
    if checkpoint_rule not in ["best_validation", "last"]:
        raise ValueError("分类模型检查点请选择best_validation或last。")
    if epochs < 1:
        raise ValueError("训练轮数必须大于零。")
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    best_accuracy = -1.0
    best_epoch = None
    best_state = deepcopy(model.state_dict())
    history = []
    for epoch in tqdm(range(epochs), desc=title, unit="轮", leave=False):
        model.train()
        optimizer.zero_grad()
        output = model(data["x"], data["edges"], data["weights"])
        # 对原始分数与已经log_softmax的输出均适用。
        loss = F.cross_entropy(output[data["train"]], data["labels"][data["train"]])
        if not torch.isfinite(loss):
            raise RuntimeError(title + "出现非有限损失。")
        loss.backward()
        optimizer.step()
        model.eval()
        with torch.no_grad():
            output = model(data["x"], data["edges"], data["weights"])
            if not torch.isfinite(output).all():
                raise RuntimeError(title + "的验证预测出现非有限值。")
            accuracy = output[data["val"]].argmax(-1).eq(data["labels"][data["val"]]).float().mean().item()
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_epoch = epoch + 1
            best_state = deepcopy(model.state_dict())
        history.append({"epoch": epoch + 1, "loss": loss.item(), "val_accuracy": accuracy})
    if snapshots is not None:
        snapshots["best_validation"] = deepcopy(best_state)
        snapshots["last"] = deepcopy(model.state_dict())
    if checkpoint_rule == "best_validation":
        model.load_state_dict(best_state)
    model.training_selection = {"rule": checkpoint_rule, "best_validation_epoch": best_epoch,
                                "selected_epoch": best_epoch if checkpoint_rule == "best_validation" else epochs}
    model.eval()
    return history
