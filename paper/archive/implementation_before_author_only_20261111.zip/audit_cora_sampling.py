"""仅用Cora固定权重核查丢边方向与触发特征可见性。"""
import argparse
import json
from pathlib import Path
import torch
from tqdm.auto import tqdm
from src.config import parser
from src.common import setup, load_training, save_json
from src.models import make_model
from src.rigbd import score_nodes, select_nodes, recover, sample_at_ratio, sample_paired
from src.evaluation import evaluate


def main():
    p = argparse.ArgumentParser(description="Cora丢边语义对照")
    p.add_argument("--bundle", type=Path, required=True)
    p.add_argument("--probe-folder", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    options = p.parse_args()
    metadata = json.loads((options.bundle / "metadata.json").read_text(encoding="utf-8"))
    if metadata["settings"]["dataset"] != "Cora":
        raise ValueError("只允许Cora数据。")
    options.output.mkdir(parents=True, exist_ok=False)
    args = parser("Cora采样对照").parse_args([])
    args.dataset, args.attack = "Cora", metadata["settings"]["attack"]
    device = setup(args.seed, args.device)
    data = load_training(options.bundle, device)
    truth = torch.load(options.bundle / "evaluation.pt", map_location=device)
    attached = truth["attached"]
    original_count = data["labels"].numel()
    changed_x = data["x"].clone()
    changed_x[original_count:] = 0
    results = []
    visibility = []
    for backbone in tqdm(["GCN", "GAT", "GraphSAGE"], desc="固定权重采样核对", unit="种"):
        args.model = backbone
        states = torch.load(options.probe_folder / (backbone + "_probe_states.pt"), map_location=device)
        probe = make_model(data, args, device, "rigbd", scoring=True)
        probe.load_state_dict(states["last"])
        probe.eval()
        with torch.no_grad():
            before = probe(data["x"], data["edges"], data["weights"])
            after = probe(changed_x, data["edges"], data["weights"])
        visibility.append({"model": backbone, "zeroed_all_new_features": True,
                           "attached_logit_max_abs_difference": float((before[attached] - after[attached]).abs().max())})
        for sampling in ["author", "incoming", "paired"]:
            setup(1010, args.device)
            scores = score_nodes(probe, data, args.rigbd_repeats, sampling=sampling)
            selected, target = select_nodes(scores, data)
            found = set(selected.cpu().tolist())
            actual = set(attached.cpu().tolist())
            row = {"model": backbone, "sampling": sampling, "inferred_target": target,
                   "selected": len(found), "TP": len(found & actual), "FP": len(found - actual),
                   "uses_evaluator_truth_in_fitting": False}
            setup(args.seed, args.device)
            model = make_model(data, args, device, "rigbd")
            if not selected.numel() or selected.numel() == data["train"].numel():
                row.update(status="selection_edge_case", metrics=None)
            else:
                recover(model, data, selected, target, args)
                row.update(status="complete", metrics=evaluate(model, data, options.bundle, "rigbd", {}, device))
            results.append(row)
            save_json(options.output / "results.json", {"dataset": "Cora", "bundle_id": metadata["bundle_id"],
                      "score_seed": 1010, "cases": results, "feature_visibility": visibility,
                      "protocol_note": "三种模式分别记录；当前正式默认值以src/config.py为准。"})
            print(backbone, sampling, row["TP"], row.get("metrics", {}), flush=True)
    save_json(options.output / "completion.json", {"status": "complete", "cases": len(results)})


if __name__ == "__main__":
    main()
