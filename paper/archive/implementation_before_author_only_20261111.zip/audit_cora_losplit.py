"""Cora同一次早期训练：比较允许首轮与排除首轮的选择规则。"""
import argparse
import json
import math
from pathlib import Path
import torch
from tqdm.auto import tqdm
from src.config import parser
from src.common import setup, load_training, save_json
from src.models import make_model
from src.training import fit_classifier
from src.losplit import parameters, recover
from src.evaluation import evaluate
from upstream.LoSplit.models.LoSplit import LoSplit
from audit_cora_rigbd import state_digest


def choose_epoch(gaps, bad, good, first):
    best = None
    for index in range(first, len(gaps)):
        if math.isfinite(float(gaps[index])) and len(bad[index]) and len(good[index]):
            if best is None or float(gaps[index]) > float(gaps[best]):
                best = index
    if best is None:
        raise RuntimeError("没有有效的早期划分。")
    return best


def main():
    p = argparse.ArgumentParser(description="仅Cora的LoSplit首轮选择控制")
    p.add_argument("--bundle", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--include-oracle", action="store_true", help="单列真实名单辅助定位，不能纳入正式对比")
    options = p.parse_args()
    meta = json.loads((options.bundle / "metadata.json").read_text(encoding="utf-8"))
    if meta["settings"]["dataset"] != "Cora":
        raise ValueError("只允许Cora数据。")
    options.output.mkdir(parents=True, exist_ok=False)
    args = parser("LoSplit配对控制").parse_args([])
    args.dataset, args.attack, args.seed = "Cora", meta["settings"]["attack"], meta["settings"]["seed"]
    device = setup(args.seed, args.device)
    data = load_training(options.bundle, device)
    truth = torch.load(options.bundle / "evaluation.pt", map_location=device) if options.include_oracle else None
    epochs, lr, gamma, _ = parameters(args)
    splitter = LoSplit(args, nfeat=data["x"].size(1), nhid=args.hidden, nclass=data["classes"],
                       dropout=args.dropout, lr=lr, weight_decay=args.weight_decay, device=device).to(device)
    bad, good, gaps, targets = splitter.fit(data["x"], data["edges"], data["weights"], data["labels"].clone(),
        data["train"], data["val"], split_epoch=epochs, num_attach=0)
    choices = {"legacy_include_first": choose_epoch(gaps, bad, good, 0),
               "fixed_exclude_first": choose_epoch(gaps, bad, good, 1)}
    rows = []
    for backbone in tqdm(["GCN", "GAT", "GraphSAGE"], desc="LoSplit三骨架配对", unit="种"):
        args.model = backbone
        modes = ["none", "legacy_include_first", "fixed_exclude_first"]
        if options.include_oracle:
            modes.append("true_ids_source")
        for mode in modes:
            setup(args.seed, args.device)
            model = make_model(data, args, device, "rigbd" if mode == "none" else "losplit")
            initial_hash = state_digest(model)
            details = {}
            if mode == "none":
                fit_classifier(model, data, args.epochs, args.lr, args.weight_decay, "无防御参考")
                epoch = None
            elif mode == "true_ids_source":
                epoch = None
                selected = truth["attached"]
                normal = data["train"][~torch.isin(data["train"], selected)]
                target = int(truth["target"])
                recover(model, data, normal, selected, target, gamma, args)
                details = {"selected_nodes": selected.cpu().tolist(), "inferred_target": target}
            else:
                epoch = choices[mode]
                selected, normal, target = bad[epoch], good[epoch], int(targets[epoch])
                recover(model, data, normal, selected, target, gamma, args)
                details = {"selected_nodes": selected.cpu().tolist(), "inferred_target": target}
            metrics = evaluate(model, data, options.bundle, "none" if mode == "none" else "losplit", details, device, args)
            rows.append({"model": backbone, "mode": mode, "early_epoch": epoch + 1 if epoch is not None else None,
                         "inferred_target": details.get("inferred_target"), "metrics": metrics,
                         "initial_parameter_sha256": initial_hash, "uses_evaluator_truth_in_fitting": mode == "true_ids_source"})
            save_json(options.output / "results.json", {"dataset": "Cora", "bundle_id": meta["bundle_id"],
                      "seed": args.seed, "cases": rows, "early_gaps": [float(v) for v in gaps], "choices": choices,
                      "control": "同一早期训练、同一恢复初始化与替代标签规则，只改变首轮是否可选。"})
            print(backbone, mode, metrics["ASR"], metrics.get("selection_TP"), flush=True)
    save_json(options.output / "completion.json", {"status": "complete", "cases": len(rows)})


if __name__ == "__main__":
    main()
