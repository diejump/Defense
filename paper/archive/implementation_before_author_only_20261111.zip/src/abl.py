"""ABL图适配：逐节点LGA、低损失隔离、普通微调和GGA。"""
from copy import copy
import torch
import torch.nn.functional as F
from tqdm.auto import tqdm
from .models import make_model, describe
from .training import fit_classifier
from .common import start_clock, elapsed


def train(data, args, device):
    if not 0 < args.abl_isolation_ratio < 1:
        raise ValueError("ABL隔离比例须在(0,1)内。")
    if args.abl_warmup_epochs < 1 or args.abl_unlearn_epochs < 1:
        raise ValueError("ABL预训练与遗忘轮数须为正。")
    model = make_model(data, args, device, "rigbd")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    history = []
    begin = start_clock(device)
    for epoch in tqdm(range(args.abl_warmup_epochs), desc="ABL局部梯度上升", unit="轮", leave=False):
        model.train()
        optimizer.zero_grad()
        output = model(data["x"], data["edges"], data["weights"])
        losses = F.cross_entropy(output[data["train"]], data["labels"][data["train"]], reduction="none")
        # 采用论文逐样本公式，图中的一个训练节点对应一个样本。
        loss = (torch.sign(losses.detach() - args.abl_loss_threshold) * losses).mean()
        if not torch.isfinite(loss):
            raise RuntimeError("ABL预训练出现非有限损失。")
        loss.backward()
        optimizer.step()
        history.append({"stage": "LGA", "epoch": epoch + 1, "loss": loss.item()})
    model.eval()
    with torch.no_grad():
        output = model(data["x"], data["edges"], data["weights"])
        losses = F.cross_entropy(output[data["train"]], data["labels"][data["train"]], reduction="none")
    count = max(1, int(data["train"].numel() * args.abl_isolation_ratio))
    order = data["train"][losses.argsort()]
    selected, normal = order[:count], order[count:]
    if not normal.numel():
        raise RuntimeError("ABL没有保留普通训练节点。")
    warmup_seconds = elapsed(begin, device)
    working = copy(data)
    working["train"] = normal
    begin = start_clock(device)
    finetune_history = fit_classifier(model, working, args.epochs, args.lr, args.weight_decay,
                                      "ABL普通组微调", checkpoint_rule="last")
    finetune_seconds = elapsed(begin, device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.abl_unlearn_lr, weight_decay=args.weight_decay)
    begin = start_clock(device)
    for epoch in tqdm(range(args.abl_unlearn_epochs), desc="ABL全局梯度上升遗忘", unit="轮", leave=False):
        model.train()
        optimizer.zero_grad()
        output = model(data["x"], data["edges"], data["weights"])
        loss = -F.cross_entropy(output[selected], data["labels"][selected])
        if not torch.isfinite(loss):
            raise RuntimeError("ABL遗忘出现非有限损失。")
        loss.backward()
        optimizer.step()
        history.append({"stage": "GGA", "epoch": epoch + 1, "loss": loss.item()})
    model.eval()
    return model, {"family": "rigbd", "final_model": describe(model), "selected_nodes": selected.cpu().tolist(),
        "protocol": "ABL论文LGA与GGA图适配；逐节点LGA、Adam、保持图连接；不同于遗忘被截零的旧图源码",
        "source": "upstream/ABL/backdoor_isolation.py与backdoor_unlearning.py；图模型复用RIGBD",
        "isolation_ratio": args.abl_isolation_ratio, "loss_threshold": args.abl_loss_threshold,
        "checkpoint_rule": "last", "history": history, "finetuning_history": finetune_history,
        "phases": {"LGA_and_selection": warmup_seconds, "clean_finetuning": finetune_seconds,
                   "GGA": elapsed(begin, device)}}
