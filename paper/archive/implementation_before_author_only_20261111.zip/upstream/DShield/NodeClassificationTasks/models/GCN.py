from tqdm.auto import tqdm
import logging

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from copy import deepcopy
import torch_geometric.nn as geo_nn
from .metric import accuracy

try:
    if 'logger' not in globals():
        logging.basicConfig()
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
except NameError:
    logging.basicConfig()
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)


class GCN(nn.Module):

    def __init__(self, n_feat, n_hid, n_class, dropout=0.5, lr=0.01,
                 weight_decay=5e-4, layer=2, device=None, layer_norm_first=False, use_ln=False):
        super(GCN, self).__init__()

        assert device is not None, '请明确指定计算设备。'
        self.device = device
        self.n_feat = n_feat
        self.hidden_sizes = [n_hid]
        self.n_class = n_class
        self.convs = nn.ModuleList()
        self.convs.append(geo_nn.GCNConv(n_feat, n_hid))
        self.lns = nn.ModuleList()
        self.lns.append(torch.nn.LayerNorm(n_feat))
        for _ in range(layer - 2):
            self.convs.append(geo_nn.GCNConv(n_hid, n_hid))
            self.lns.append(nn.LayerNorm(n_hid))
        self.lns.append(nn.LayerNorm(n_hid))
        self.gc2 = geo_nn.GCNConv(n_hid, n_class)
        self.dropout = dropout
        self.lr = lr
        self.weight_decay = weight_decay

        self.layer_norm_first = layer_norm_first
        self.use_ln = use_ln

        # Explainability
        self.layer = layer
        self.embedding_size = n_hid

    def initialize(self):
        """Initialize parameters of GCN.
        """
        for conv in self.convs:
            conv.reset_parameters()
        for ln in self.lns:
            ln.reset_parameters()
        self.gc2.reset_parameters()

    def embedding(self, features, edge_index, edge_weight=None):

        if self.layer_norm_first:
            features = self.lns[0](features)
        num_convs = len(self.convs)
        for idx, conv in enumerate(self.convs):
            features = F.relu(conv(features, edge_index, edge_weight))
            if idx >= num_convs - 1:
                break
            if self.use_ln:
                features = self.lns[idx + 1](features)
            features = F.dropout(features, self.dropout, training=self.training)
        return features

    def forward(self, x, edge_index, edge_weight=None, rtn_mid=False):

        if self.layer_norm_first:
            x = self.lns[0](x)
        i = 0
        for conv in self.convs:
            x = F.relu(conv(x, edge_index, edge_weight))
            if self.use_ln:
                x = self.lns[i + 1](x)
            i += 1
            x = F.dropout(x, self.dropout, training=self.training)
        mid_feat = x.clone()
        x = self.gc2(x, edge_index, edge_weight)
        if rtn_mid is True:
            return x, mid_feat
        return x

    def get_h(self, features, edge_index):
        for conv in self.convs:
            features = F.relu(conv(features, edge_index))
        return features

    def fit(self, features, edge_index, edge_weight, labels, idx_train, idx_val=None, train_iters=200, verbose=False):
        """Train the gcn model, when idx_val is not None, pick the best model according to the validation loss.
        Parameters
        ----------
        features :
            node features
        edge_index:
            the adjacency matrix. The format could be torch.tensor or scipy matrix
        edge_weight:
            weights of edges
        labels :
            node labels
        idx_train :
            node training indices
        idx_val :
            node validation indices. If not given (None), GCN training process will not adopt early stopping
        train_iters : int
            number of training epochs
        verbose : bool
            whether to show verbose logs
        """

        edge_index, edge_weight = edge_index.to(self.device), edge_weight.to(self.device)
        features = features.to(self.device)
        labels = labels.to(self.device)

        if idx_val is None:
            self._train_without_val(features, edge_index, edge_weight, labels, idx_train, train_iters, verbose)
        else:
            self._train_with_val(features, edge_index, edge_weight, labels, idx_train, idx_val, train_iters, verbose)

    def _train_without_val(self, features, edge_index, edge_weight, labels, idx_train, train_iters, verbose):
        self.train()
        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        for i in tqdm(range(train_iters), desc='GCN 模型训练', unit='轮', dynamic_ncols=True, leave=False, mininterval=0.5):
            optimizer.zero_grad()
            output = self.forward(features, edge_index, edge_weight)
            loss_train = F.cross_entropy(output[idx_train], labels[idx_train])
            loss_train.backward()
            optimizer.step()
            if verbose and i % 10 == 0:
                logger.info('轮数 {}，训练损失：{}'.format(i, loss_train.item()))

        self.eval()
        output = self.forward(features, edge_index, edge_weight)
        return output

    def _train_with_val(self, features, edge_index, edge_weight, labels, idx_train, idx_val, train_iters, verbose):
        if verbose:
            logger.info('开始训练图神经网络模型')
        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        best_loss_val = 100
        best_acc_val = -1.0
        weights = None
        for i in tqdm(range(train_iters), desc='GCN 模型训练', unit='轮', dynamic_ncols=True, leave=False, mininterval=0.5):
            self.train()
            optimizer.zero_grad()
            output = self.forward(features, edge_index, edge_weight)
            loss_train = F.cross_entropy(output[idx_train], labels[idx_train])
            loss_train.backward()
            optimizer.step()

            self.eval()
            output = self.forward(features, edge_index, edge_weight)
            loss_val = F.cross_entropy(output[idx_val], labels[idx_val])
            acc_val = accuracy(output[idx_val], labels[idx_val])

            if verbose and i % 10 == 0:
                logger.info('轮数 {}，训练损失：{}'.format(i, loss_train.item()))
                logger.info('验证准确率：{:.4f}'.format(acc_val))
            if acc_val > best_acc_val:
                best_acc_val = acc_val
                weights = deepcopy(self.state_dict())
        logger.info('验证集最佳准确率：{:.4f}'.format(best_acc_val))

        if verbose:
            logger.info('根据验证集表现恢复最佳模型参数')
        self.load_state_dict(weights)

    def test(self, features, edge_index, edge_weight, labels, idx_test):
        """Evaluate GCN performance on test set.
        Parameters
        ----------
        idx_test :
            node testing indices
        """
        self.eval()
        with torch.no_grad():
            output = self.forward(features, edge_index, edge_weight)
            acc_test = accuracy(output[idx_test], labels[idx_test])
        return float(acc_test)

    def test_with_correct_nodes(self, features, edge_index, edge_weight, labels, idx_test):
        self.eval()
        output = self.forward(features, edge_index, edge_weight)
        correct_nids = (output.argmax(dim=1)[idx_test] == labels[idx_test]).nonzero().flatten()  # return a tensor
        acc_test = accuracy(output[idx_test], labels[idx_test])
        return acc_test, correct_nids
